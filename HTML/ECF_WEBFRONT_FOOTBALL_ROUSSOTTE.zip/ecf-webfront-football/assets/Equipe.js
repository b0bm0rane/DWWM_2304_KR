class Equipe {

    constructor(_equipeFromJson) 
    
    {

        Object.assign(this, _equipeFromJson);

    }

}

export { Equipe };
